# SIRIAI Training Campus v3 · Golden Hour

소현님을 위한 인플루언서 모집 업무 교육 맵. 6개 공간, 18개 활동을 그림과 모의 화면으로 직접 조작하는 Roblox용 프로젝트입니다.

v3는 노을이 지는 황금빛 갈대밭에 나무 정자 여섯 곳을 배치한 풍경입니다. 갈대 사이의 데크 산책길이 호수와 벤치가 있는 쉼터로 이어집니다. 가까운 갈대는 바람에 움직이고, 호수에는 Roblox Terrain 물을 사용합니다. 조명·대기·구름과 식물·소품은 프로젝트 안에 포함됩니다.

v2에서 도입한 비주얼 교육을 유지합니다. 같은 선택지를 반복하는 형식을 줄이고 프로필 미리보기, 크롬 옵션 찾기, 연결 화면 조작, 일러스트 계정 카드, DM·시트 작업, 희망 고료 기록·공유, 정산표 시각화로 바꿨습니다. 일러스트 8종은 원본 도형 데이터로 제작해 웹과 Roblox에서 함께 사용합니다.

## 바로 열기

1. `downloads/SIRIAI_Training_Campus_v3.rbxlx`를 받습니다. 기존 맵 파일을 열어둔 경우 새 파일을 다시 열어야 변경 내용이 적용됩니다. 기본 다운로드 주소도 v3 파일로 유지합니다. 이름에 v2가 붙은 파일은 이전 버전입니다.
2. PC의 **Roblox Studio → 파일 열기**에서 이 파일을 선택합니다.
3. **플레이**를 누르면 환영 화면과 교육 미션이 시작됩니다.
4. 계정에 올릴 때는 Studio의 **Roblox에 게시**를 사용하고, 원하는 이용 권한을 설정합니다. 실제 Roblox 경험 링크는 게시 후 생깁니다.

브라우저의 `index.html`에서 18개 활동의 웹 조작 체험과 노을·물가·전체 시점으로 3D 풍경을 확인할 수 있습니다. 같은 지형 도형을 사용하되, 웹의 하늘·물·조명은 별도 렌더러로 표현하므로 Roblox 화면과는 다를 수 있습니다. 웹 체험은 Roblox 실행 화면을 캡처한 것이 아니며, 같은 교육 데이터와 일러스트를 사용하는 조작 미리보기입니다.

## 교육 구성

| 순서 | 공간 | 연습 내용 |
|---|---|---|
| 1 | 프로필 스튜디오 | 제공 자료로 프로필 준비, 소개 문구, 업무 범위 |
| 2 | 연결 연구실 | IG Lead Saver 옵션 열기, 연결 순서, 기본 상태 |
| 3 | 크리에이터 가든 | 캠페인 적합도, 기존 접촉, 수집 지원 요청 |
| 4 | DM 포스트오피스 | 팔로워 구간별 문구, 발송 후 표시, 유효 발송 |
| 5 | 리플라이 카페 | 고료 조정 요청, 어려운 문의, 지원과 선정 구분 |
| 6 | 리워드 라운지 | 300원 기본 보수, 2,000원 선정 인센티브, 정산 예시 |

교육용 팔로워 조건·고료·가상 계정은 실제 캠페인 조건이 아닙니다. 실제 DM에는 기본 제안 고료가 들어 있으며, 조정을 희망하는 인원은 희망 금액을 기록·공유합니다. 최종 선정은 브랜드에서 진행합니다.

## 조작과 진행

- 이동: PC `WASD`, 모바일 화면 조이스틱. 점프: 스페이스 / 모바일 점프 버튼.
- 미션: 단말기 가까이에서 `E`, 게임패드 `X`, 또는 화면의 터치 버튼.
- 오른쪽 위 **미션지도**에서 현재·완료한 공간으로 이동할 수 있습니다. PC에서는 `M`도 가능합니다.
- **노을 산책**: 물가 쉼터로 이동하고 교육 HUD를 잠시 숨깁니다. **교육으로 돌아가기**를 누르면 마지막 교육 공간으로 돌아옵니다. 완료한 미션·스탬프는 유지되며, 풀던 활동은 단말기에서 다시 열 수 있습니다. 벤치에 앉아서 풍경을 볼 수도 있습니다.
- 프로필은 그림 카드를 적용하고, 확장프로그램은 모의 설정 화면에서 연결 순서를 직접 조작합니다.
- 수집은 콘텐츠 그림·팔로워 정보를 보고 계정 카드를 선택합니다. DM은 발송 후 시트 상태까지 변경합니다.
- 고료 조정은 답장·비고 금액·공유를 모두 완료해야 통과합니다. 정산은 단가 칩을 넣으면 합계와 그래프가 바뀝니다.
- 틀린 작업은 설명과 결과 그림을 보고 다시 연습합니다.
- 스탬프는 서버에서 각 플레이어별로 계산합니다. 완료한 공간을 복습해도 중복 지급되지 않습니다.
- 미션 도중 닫거나 캐릭터가 다시 생성되면 이번 접속의 완료 단계가 유지됩니다. 재접속하면 처음부터 새 연습을 시작합니다. 영구 저장은 사용하지 않습니다.
- 마지막 미션 이후 수료 화면, 수료 데크, 화면 종이 조각 효과가 나옵니다. Roblox 공식 배지나 실제 보수를 지급하는 기능은 아닙니다.

실제 외부 계정, 업무 시트, DM 발송 서비스에 연결하지 않습니다. 확장프로그램의 실제 설치·세팅은 별도로 전달한 업무 안내서에서 진행합니다.

## 수정과 빌드

- `src/server/Curriculum.json`: 교육 문구·정답·공간 정보
- `src/server/TrainingEngine.lua`: 미션 진행과 채점
- `src/server/TrainingServer.server.lua`: 개인별 진행·단말기·이동·서버 검증
- `src/client/TrainingClient.client.lua`: 한국어 PC/모바일 UI
- `src/client/VisualTutorials.lua`: 15가지 화면 유형으로 구성한 18개 조작 활동
- `src/client/VisualAssets.json`: 8종 원본 일러스트의 도형 데이터
- `tutorial-demo.js`, `tutorial-demo.css`: 웹에서 확인하는 조작 체험
- `build_map.py`: 외부 모델 없이 기본 도형으로 만드는 맵
- `meadow_environment.py`: 황금빛 갈대·목재 산책길·정자·호수·쉼터 생성
- `environment.json`: 웹의 세 카메라 시점·호수·환경 정보
- `src/server/MeadowWater.server.lua`: 네이티브 Terrain 물과 바람 설정
- `src/client/MeadowBreeze.client.lua`: 가까운 40개 갈대 군락만 12Hz로 움직임
- `map/TrainingMap.model.json`: 생성된 3D 공간
- `default.project.json`: Rojo 프로젝트

Python 3와 [Rojo](https://rojo.space/docs/v7/)가 있는 환경에서:

```sh
python build_map.py
rojo build default.project.json -o downloads/SIRIAI_Training_Campus.rbxlx
```

[Luau CLI](https://github.com/luau-lang/luau/releases)로 검증:

```sh
luau-compile --null src/server/TrainingEngine.lua src/server/TrainingServer.server.lua src/client/TrainingClient.client.lua src/client/VisualTutorials.lua
python tests/run_tests.py --luau /path/to/luau
python tests/environment.spec.py
```

## 확인 범위

Rojo 7.7.1로 파일 빌드, Luau 0.744 구문 검증, 318개 상태·진행 검증, 실제 UI 콜백을 실행하는 데스크톱·모바일 어댑터 36개 경로 검증, 실제 서버 코드의 산책·복귀 12개 검증, 실제 내보낸 파일의 6개 단말기·스크립트 구조 검증을 완료했습니다. 웹 미리보기는 PC·모바일에서 활동 조작과 3D 공간을 확인합니다. v3 환경에는 충돌 없는 갈대, 이어진 데크, 2개 Seat, 노을 조명과 물 생성 스크립트가 포함됩니다. 웹은 반복 도형을 InstancedMesh로 묶고 화면 밖에서는 렌더링을 멈춥니다. 움직임 감소 설정에서는 웹 바람을 멈춥니다. 어댑터 검증은 실제 Roblox 렌더링 테스트를 대신하지 않습니다. **Roblox Studio의 실제 플레이 테스트와 Roblox 계정 게시·공개 설정은 이 환경에서 수행하지 않았습니다.**

## 제작 자료

맵의 공간·가구·표지·식물·트로피와 교육용 일러스트는 기본 도형으로 직접 제작했습니다. 그림은 native GUI 도형으로 표시하므로 별도 이미지 업로드나 외부 에셋 ID 설정 없이 열 수 있습니다. 외부 무료 모델, 메시, 이미지, 음원, 외부 Roblox 에셋 ID를 사용하지 않았습니다. 이후 제3자 자료를 추가하는 경우 해당 자료의 이용 권한을 별도로 확인해주세요.

웹 미리보기만 Three.js 0.180.0(MIT)와 Pretendard(OFL)를 사용합니다. 각 라이선스는 `vendor/THREE-LICENSE.txt`, `assets/Pretendard-LICENSE.txt`에 포함되어 있습니다.
