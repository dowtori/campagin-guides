"""Shared walking route: one forward pass through three work locations."""
SPAWN=(-34,100)
PATH=[(-34,100),(-34,82),(-34,50),(-34,24),(-34,-8),(-34,-40),(-34,-63),(0,-94),(0,-140),(0,-180),(0,-220),(-5,-255),(4,-285),(0,-330)]
TARGETS={
 'Manager':{'position':(-34,5,82),'caption':'캠페인 준비','place':'준비 테라스'},
 'DiscoveryDesk':{'position':(-34,5,24),'caption':'태그됨에서 계정 수집','place':'수집 PC'},
 'Mailbox':{'position':(-34,5,-40),'caption':'DM과 회신 확인','place':'DM 데스크'},
}
