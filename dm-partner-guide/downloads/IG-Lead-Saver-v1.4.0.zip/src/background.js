/* IG Lead Saver — service worker
 * Apps Script 웹앱으로의 통신을 전담한다.
 * (content script에서 직접 쏘면 CORS에 막히지만, host_permissions를 가진
 *  확장 백그라운드에서는 통과된다.)
 */

const DEFAULTS = {
  webAppUrl: '',
  sheetName: '인플루언서',
  savedBy: '',            // 누가 저장했는지 — 팀 업무 배분용. 로그인 없이 이름만 남긴다.
  defaultStatus: '연락전',
  defaultTag: '',
  enableFeedButtons: true,
  enableListButtons: true,
  enableGridButtons: true,
  gridAutoResolve: true
};

async function getSettings() {
  const cfg = await chrome.storage.sync.get(DEFAULTS);
  return { ...DEFAULTS, ...cfg };
}

/**
 * Apps Script 웹앱 호출.
 * Content-Type을 text/plain으로 두면 preflight 없이 단순 요청으로 나가고,
 * Apps Script는 e.postData.contents로 원문을 그대로 받는다.
 */
async function callSheet(action, body) {
  const { webAppUrl } = await getSettings();
  if (!webAppUrl) {
    return { ok: false, error: '구글시트 웹앱 URL이 설정되지 않았습니다. 확장 옵션에서 등록해주세요.' };
  }

  let res;
  try {
    res = await fetch(webAppUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action, ...body }),
      redirect: 'follow'
    });
  } catch (e) {
    return { ok: false, error: `네트워크 오류: ${e.message}` };
  }

  const text = await res.text();
  if (!res.ok) {
    return { ok: false, error: `시트 응답 오류 ${res.status}` };
  }

  try {
    return JSON.parse(text);
  } catch (_) {
    // 로그인 화면 HTML이 돌아오는 경우 = 배포 시 접근권한 설정 문제
    if (/accounts\.google\.com|<html/i.test(text)) {
      return {
        ok: false,
        error: '웹앱이 JSON 대신 로그인 페이지를 반환했습니다. Apps Script 배포 시 "액세스 권한: 모든 사용자"로 설정해주세요.'
      };
    }
    return { ok: false, error: '시트 응답을 해석하지 못했습니다.' };
  }
}

/** 로컬 저장 사용자 캐시 갱신 */
async function markSaved(username) {
  const st = await chrome.storage.local.get(['savedUsernames', 'knownUsernames']);
  const savedUsernames = st.savedUsernames || [];
  const knownUsernames = st.knownUsernames || [];
  const lower = username.toLowerCase();
  const patch = {};

  if (!savedUsernames.some((u) => u.toLowerCase() === lower)) {
    savedUsernames.push(username);
    patch.savedUsernames = savedUsernames;
  }
  // 방금 저장한 계정은 이력에도 들어간다. 여기서 같이 넣어두지 않으면
  // 다른 캠페인으로 옮겼을 때 '기존 접촉'으로 안 뜬다.
  if (!knownUsernames.some((u) => u.toLowerCase() === lower)) {
    knownUsernames.push(username);
    patch.knownUsernames = knownUsernames;
  }
  if (Object.keys(patch).length) await chrome.storage.local.set(patch);
}

/**
 * 이력 목록을 주기적으로 새로 받아온다.
 * 수동 버튼에만 의존하면 팀원 A가 저장한 계정을 팀원 B가 모른 채 중복 저장한다.
 */
const KNOWN_TTL_MS = 3 * 60 * 60e3;   // 3시간

async function refreshKnownIfStale(force) {
  const s = await getSettings();
  if (!s.webAppUrl) return { ok: false, error: 'no_url' };

  const { knownSyncedAt = 0 } = await chrome.storage.local.get('knownSyncedAt');
  if (!force && Date.now() - knownSyncedAt < KNOWN_TTL_MS) return { ok: true, skipped: true };

  const res = await callSheet('list', { sheetName: s.sheetName });
  if (res.ok) {
    await chrome.storage.local.set({
      savedUsernames: Array.isArray(res.current) ? res.current : [],
      knownUsernames: Array.isArray(res.known) ? res.known : [],
      knownSyncedAt: Date.now()
    });
  }
  return res;
}

async function pushRecent(entry) {
  const { recent = [] } = await chrome.storage.local.get('recent');
  recent.unshift(entry);
  await chrome.storage.local.set({ recent: recent.slice(0, 30) });
}

// ── 메시지 라우터 ────────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      switch (msg?.type) {
        case 'SAVE_LEAD': {
          const s = await getSettings();
          const payload = {
            ...msg.payload,
            savedBy: s.savedBy,
            status: s.defaultStatus,
            tag: s.defaultTag
          };
          const res = await callSheet('append', { sheetName: s.sheetName, lead: payload });
          if (res.ok) {
            await markSaved(payload.username);
            await pushRecent({
              username: payload.username,
              fullName: payload.fullName,
              followers: payload.followers,
              profileUrl: payload.profileUrl,
              at: Date.now(),
              status: res.status,
              campaign: s.sheetName,
              savedBy: s.savedBy
            });
          }
          sendResponse(res);
          break;
        }

        case 'PING_SHEET': {
          const s = await getSettings();
          sendResponse(await callSheet('ping', { sheetName: s.sheetName }));
          break;
        }

        case 'SYNC_SAVED': {
          sendResponse(await refreshKnownIfStale(true));
          break;
        }

        // 콘텐츠 스크립트가 페이지를 열 때마다 부른다. 오래됐을 때만 실제로 받아온다.
        case 'REFRESH_KNOWN': {
          sendResponse(await refreshKnownIfStale(false));
          break;
        }

        case 'LIST_SHEETS': {
          sendResponse(await callSheet('listSheets', {}));
          break;
        }

        case 'CREATE_SHEET': {
          const res = await callSheet('createSheet', { newSheetName: msg.name });
          if (res.ok) await chrome.storage.sync.set({ sheetName: res.created });
          sendResponse(res);
          break;
        }

        case 'SET_CONFIG': {
          // 인스타 화면의 독에서 저장자·캠페인을 바로 바꿀 수 있게 한다
          const patch = {};
          if (typeof msg.savedBy === 'string') patch.savedBy = msg.savedBy.trim();
          if (typeof msg.sheetName === 'string' && msg.sheetName.trim()) patch.sheetName = msg.sheetName.trim();
          await chrome.storage.sync.set(patch);
          // 캠페인이 바뀌면 '저장됨' 표시 기준도 바뀌므로 목록을 다시 받아온다
          if (patch.sheetName) {
            const res = await callSheet('list', { sheetName: patch.sheetName });
            if (res.ok) {
              await chrome.storage.local.set({
                savedUsernames: Array.isArray(res.current) ? res.current : [],
                knownUsernames: Array.isArray(res.known) ? res.known : []
              });
            }
          }
          sendResponse({ ok: true, ...patch });
          break;
        }

        default:
          sendResponse({ ok: false, error: `알 수 없는 요청: ${msg?.type}` });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
  })();
  return true; // 비동기 응답
});

// ── 단축키 ──────────────────────────────────────────────────────────────────
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'save-current-profile') return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !/^https:\/\/www\.instagram\.com\//.test(tab.url || '')) return;
  chrome.tabs.sendMessage(tab.id, { type: 'SAVE_CURRENT', source: '단축키' }).catch(() => {});
});

// ── 우클릭 메뉴: 프로필 링크에서 바로 저장 ──────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'igls-save-link',
    title: '이 프로필을 시트에 저장',
    contexts: ['link'],
    documentUrlPatterns: ['https://www.instagram.com/*'],
    targetUrlPatterns: ['https://www.instagram.com/*']
  });
  chrome.contextMenus.create({
    id: 'igls-save-page',
    title: '현재 프로필을 시트에 저장',
    contexts: ['page'],
    documentUrlPatterns: ['https://www.instagram.com/*']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab?.id) return;
  if (info.menuItemId === 'igls-save-page') {
    chrome.tabs.sendMessage(tab.id, { type: 'SAVE_CURRENT', source: '우클릭' }).catch(() => {});
  }
  if (info.menuItemId === 'igls-save-link' && info.linkUrl) {
    chrome.tabs
      .sendMessage(tab.id, { type: 'SAVE_LINK', url: info.linkUrl, source: '우클릭(링크)' })
      .catch(() => {});
  }
});
